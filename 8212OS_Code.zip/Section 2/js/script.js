

var wnd = $(window);
wnd.ready(function(){

	$('#dres span').text(screen.width + "X" + screen.height);

	refresh();

});

wnd.resize(refresh);

function refresh(){
	$('#bres span').text(wnd.width()+"X"+wnd.height());

}

function getRatio(wid,hei){
	
}