var aTopicsAll=[
	["What are Media Queries?",
	"Media Types",
	"How to design sites in a Media rich world?",
	"Start from scratch or tweak for medias?",
	"The case for Mobile first."],
	["Media Queries Hello World.",
	"Two ways to define Media Queries. ",
	"Why set media queries file wide?",
	"The print case."],
	["Two ways: second way.",
	"The @media rule.",
	"What's better?",
	"All the media types."],
	["Media Query rule combination.",
	"Media Queries as connectable items.",
	"The and operator.",
	"The not operator.",
	"The only operator.",
	"Browser compatibility.",
	"Next stop : expressions"]
	
	];
var aTopics=aTopicsAll[3];

var wnd = $(window);
wnd.ready(function(){

	$('#dres span').text(screen.width + "X" + screen.height);

	aTopics.push($('.article h1').text());
	$('.article h1').click(function(){
		if(aTopics.length)
			$(this).text(aTopics.shift());
	});

	refresh();

});

wnd.resize(refresh);



function refresh(){
	console.log(wnd.height());
	$('#bres span').text(wnd.width()+"X"+wnd.height());

}